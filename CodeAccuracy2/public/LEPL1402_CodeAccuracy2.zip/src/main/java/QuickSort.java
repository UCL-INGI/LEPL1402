public class QuickSort {

    // This class should not be instantiated.
    private QuickSort() {
    }

    public static void sort(Comparable[] a) {
        // TODO TO BE COMPLETED
        // TODO DON'T FORGET ASSERTIONS
    }

    public static void sort(Comparable[] a, int left, int right) {
        // TODO TO BE COMPLETED
        // TODO DON'T FORGET ASSERTIONS
    }

    public static void swap(Object[] a, int i, int j) {
        // TODO TO BE COMPLETED
        // TODO DON'T FORGET ASSERTIONS
    }

    // should return the index of the pivot
    public static int partition(Comparable[] a, int left, int right) {
        // TODO TO BE COMPLETED
        // TODO DON'T FORGET ASSERTIONS
    }

}