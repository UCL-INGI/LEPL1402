import java.util.BitSet;

public class Sieve{
    
    public static BitSet bits; //You should work on this BitSet
    
    public static int numberOfPrime(int n){
        //TODO By Student
    }
    
}