import java.util.Stack;

public class MyQueue<E> {

    Stack<E> s1;
    Stack<E> s2;

    private E front;

    /*
     * Constructor
     */
    public MyQueue() {
        s1 = new Stack<>();
        s2 = new Stack<>();
        this.front = null;
    }

    public void enqueue(E elem) {
      //TODO
    }

    public E dequeue() {
      //TODO
    }

    public E peek() {
      //TODO
    }

    public boolean empty() {
      //TODO
    }

}
