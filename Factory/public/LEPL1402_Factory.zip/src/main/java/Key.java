
public class Key implements LevelComponent {

    public Key(){}

    public String draw(){
        return "K";
    }

}
