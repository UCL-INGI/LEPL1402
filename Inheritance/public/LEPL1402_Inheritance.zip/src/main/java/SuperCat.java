public class SuperCat extends Cat {

    public void clear_log() {
        /**
         * TODO : How can you clear the StringBuffer we obtained by inheritance ?
         * ( Super Heroes like SuperCat want to keep their secret actions private )
         */
    }

}
