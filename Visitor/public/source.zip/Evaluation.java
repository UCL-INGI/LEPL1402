public class Evaluation implements Visitor {
    // YOUR CODE HERE
}
