public class Leaf implements Visitable {
    
    // YOUR CODE HERE

    public int getValue() {
        // YOUR CODE HERE
    }
}
