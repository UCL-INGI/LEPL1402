public class Add extends Node implements Visitable {
    // YOUR CODE HERE
}
