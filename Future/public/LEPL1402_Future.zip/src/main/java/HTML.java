import java.util.List;

public class HTML {

    private List<URL> urls;

    public HTML(){
      //HIDDEN TO YOU
    }

    public List<URL> getUrls(){
        return this.urls;
    }
}
