public class Image {
  //HIDDEN
}
