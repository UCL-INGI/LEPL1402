public class Fibonacci {


    public static int fiboRecursive(int index){
        //TODO HERE CODE HERE
    }


    public static int fiboIterative(int index){
        //TODO YOUR CODE HERE
    }

}
