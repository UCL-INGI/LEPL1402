public class Cons<T> implements IStream<T> {

    //TODO one variable called head and one variable called tail
    // and the constructor

    @Override
    public T head() {
        //HIDDEN TO YOU
    }

    @Override
    public IStream<T> tail() {
        //HIDDEN TO YOU
    }

    @Override
    public boolean isEmpty() {
        //HIDDEN TO YOU
    }
}
