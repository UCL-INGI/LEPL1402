
import java.util.ArrayList;
import java.util.List;

public class Except{
    
    
    public static void outof(){
        
    }
    
    public static void concurr(){
        
    }
    
    public static void nullpointer(){
        
    }
    
    
    
}