public class Valley{
    /*
     * Example:
     * [1, 1, 1, -1, -1, -1, -1, -1, 1, 1, 1, 1, 1, 1, -1, -1]
     * Should return
     * [5, 3]
     */

     public static int[] valley ( int[] array){
     //TODO By Student

    }
}
