
public class Leaf<A> extends FTree<A> {

    private final A value;

    public Leaf(A a){
        
    }
    //TODO by student
}
