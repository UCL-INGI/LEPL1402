
public class Search {

    /**
     *
     * @param tab
     * @return
     */
    public static int search(int[] tab, int elem){
        //TODO
    }
}
